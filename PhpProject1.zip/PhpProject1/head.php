<?php 
?>
<head>
        <link rel="stylesheet" type="text/css" href="basic.css">
        <title>Input name - a form </title>
        
	
</head>
