<?php

$dbc = mysqli_connect('localhost', 'dev', 'loapsw', 'budget_planning') OR die('Error' . mysqli_connect_errno());

?>